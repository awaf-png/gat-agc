"""Smoke tests for the policy networks."""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from gatagc.environment import HybridMicrogridEnv
from gatagc.networks import ActorCritic


def test_gat_forward_and_param_count():
    env = HybridMicrogridEnv(seed=0, episode_steps=5)
    obs = env.reset()
    net = ActorCritic(encoder="gat")
    mean, value = net(obs)
    assert mean.shape[-1] == 3
    assert value.dim() == 1
    # The actor-critic is on the order of tens of thousands of
    # parameters and independent of bus count (Table 3).
    assert 30_000 < net.num_parameters() < 120_000


def test_act_is_bounded():
    env = HybridMicrogridEnv(seed=1, episode_steps=5)
    obs = env.reset()
    net = ActorCritic(encoder="gat")
    a, logp, v = net.act(obs)
    assert float(a.min()) >= -1.0 and float(a.max()) <= 1.0


def test_all_encoders_run():
    env = HybridMicrogridEnv(seed=2, episode_steps=5)
    obs = env.reset()
    for enc in ("gat", "gcn", "mlp"):
        net = ActorCritic(encoder=enc)
        mean, value = net(obs)
        assert mean.shape[-1] == 3
