"""Smoke tests for the microgrid environment."""

import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from gatagc.environment import HybridMicrogridEnv


def test_reset_shapes():
    env = HybridMicrogridEnv(seed=0, episode_steps=10)
    obs = env.reset()
    assert obs.x.shape == (6, 8)
    assert obs.edge_index.shape[0] == 2
    assert obs.edge_attr.shape[1] == 4


def test_step_returns_finite_reward():
    env = HybridMicrogridEnv(seed=1, episode_steps=10)
    env.reset()
    obs, r, done, info = env.step(np.zeros(3, dtype=np.float32))
    assert np.isfinite(r)
    assert set(["ace", "df", "fuel"]).issubset(info)


def test_episode_runs_to_completion():
    env = HybridMicrogridEnv(seed=2, episode_steps=20)
    env.reset()
    steps = 0
    done = False
    while not done:
        _, _, done, _ = env.step(np.zeros(3, dtype=np.float32))
        steps += 1
    assert steps == 20
    s = env.episode_summary()
    assert 0.0 <= s["renewable_util_pct"] <= 100.0


def test_line_outage_changes_edges():
    env = HybridMicrogridEnv(seed=3, episode_steps=5)
    env.reset()
    before = env.edge_index.shape[1]
    env.set_line_outage(2)
    after = env.edge_index.shape[1]
    assert after < before


def test_larger_system_builds():
    env = HybridMicrogridEnv(seed=4, n_buses=20, episode_steps=5)
    obs = env.reset()
    assert obs.x.shape == (20, 8)
