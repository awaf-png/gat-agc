# Reproducibility

This document records the exact protocol used to produce the results in
the paper.

## Software environment

The experiments were run with Python 3.10, PyTorch 2.x and PyTorch
Geometric 2.x. Exact pinned versions are recorded in each run's
metadata JSON under `checkpoints/`. CPU execution is sufficient; a GPU
only shortens training time.

## Seeds

The main evaluation window uses ten fixed seeds:

```
13, 21, 34, 55, 89, 144, 233, 377, 610, 987
```

The ablation study uses a separate dedicated seed (`2024`) so that the
"GAT (full proposed)" row of the ablation table is independent of the
main evaluation window. Both lists are defined in
`src/gatagc/seeding.py`.

## Protocol

1. Train GAT-AGC, GCN-AGC and DDPG-AGC for 1000 episodes on the 6-bus
   benchmark, once per seed.
2. Evaluate all six controllers for 200 episodes under common random
   seeds (evaluation seed base 1000), producing Tables 4 and 5.
3. Apply paired Wilcoxon signed-rank tests across the ten seeds for
   every GAT-AGC vs. baseline contrast.
4. Evaluate the trained 6-bus GAT policy, without retraining, on the
   10/14/20-bus systems for the scalability figure.
5. Trip line Bus2-Bus3 and record reward degradation for the
   topology-robustness figure.
6. Run the ablation variants under the ablation seed for Table 6.

Steps 1-6 are driven by the scripts in `scripts/`. Each training run
writes a metadata JSON next to its checkpoint recording the seed,
episode count, wall-clock time and final reward.

## Notes

* All operating data (disturbances, renewable profiles, IoT noise) is
  generated online from the models in `environment.py`. No external
  dataset is used or required.
* Controller comparisons use identical disturbance, renewable and IoT
  noise realizations per seed, so differences are attributable to the
  controller alone.
