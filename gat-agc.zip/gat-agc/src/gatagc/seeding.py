"""Reproducibility helpers."""

from __future__ import annotations

import os
import random

import numpy as np
import torch


def set_global_seed(seed: int) -> None:
    """Seed Python, NumPy and PyTorch RNGs for reproducible runs."""
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(False)


# Random seeds used for the main 10-seed evaluation window.
MAIN_SEEDS = [13, 21, 34, 55, 89, 144, 233, 377, 610, 987]

# Seed reserved for the ablation-specific evaluation.
ABLATION_SEED = 2024
