"""GAT-AGC: Graph Attention Network for Automatic Generation Control
in IoT-enabled hybrid AC/DC microgrids.
"""

__version__ = "1.0.0"
