"""Policy and value networks.

Three interchangeable graph encoders are provided:

* :class:`GATEncoder`  - three multi-head graph attention layers
  (4, 2, 1 heads) producing a 64-dim per-node embedding. Used by the
  proposed GAT-AGC controller.
* :class:`GCNEncoder`  - three graph-convolution layers with the same
  width, used for the no-attention ablation (GCN-AGC).
* :class:`MLPEncoder`  - a permutation-invariant per-node MLP followed
  by global pooling, used for the no-graph ablation.

All encoders emit a 128-dim graph embedding (mean+max pooling) that is
shared by the actor and critic heads. Because every weight matrix is
indexed by feature dimension rather than by bus index, the same
parameters apply to graphs of any size.
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, GCNConv, global_max_pool, global_mean_pool


class GATEncoder(nn.Module):
    def __init__(self, in_dim: int = 8, edge_dim: int = 4):
        super().__init__()
        # Layer widths chosen so that the full actor-critic has the
        # ~73.5k parameters reported in Table 3, with 4, 2, 1 heads.
        self.g1 = GATConv(in_dim, 32, heads=4, concat=True,
                          edge_dim=edge_dim, dropout=0.0)
        self.g2 = GATConv(32 * 4, 64, heads=2, concat=True,
                          edge_dim=edge_dim, dropout=0.0)
        self.g3 = GATConv(64 * 2, 64, heads=1, concat=True,
                          edge_dim=edge_dim, dropout=0.0)
        self.out_dim = 128
        self._last_attention = None

    def forward(self, x, edge_index, edge_attr, batch):
        h = F.elu(self.g1(x, edge_index, edge_attr))
        h = F.elu(self.g2(h, edge_index, edge_attr))
        h, att = self.g3(h, edge_index, edge_attr,
                         return_attention_weights=True)
        h = F.elu(h)
        self._last_attention = att
        return torch.cat([global_mean_pool(h, batch),
                          global_max_pool(h, batch)], dim=-1)

    def attention_entropy(self) -> float:
        if self._last_attention is None:
            return 0.0
        _, alpha = self._last_attention
        a = alpha.detach().flatten().clamp_min(1e-12)
        a = a / a.sum()
        return float(-(a * a.log()).sum())


class GCNEncoder(nn.Module):
    def __init__(self, in_dim: int = 8, edge_dim: int = 4):
        super().__init__()
        self.g1 = GCNConv(in_dim, 256)
        self.g2 = GCNConv(256, 256)
        self.g3 = GCNConv(256, 64)
        self.out_dim = 128

    def forward(self, x, edge_index, edge_attr, batch):
        h = F.relu(self.g1(x, edge_index))
        h = F.relu(self.g2(h, edge_index))
        h = F.relu(self.g3(h, edge_index))
        return torch.cat([global_mean_pool(h, batch),
                          global_max_pool(h, batch)], dim=-1)

    def attention_entropy(self) -> float:
        return 0.0


class MLPEncoder(nn.Module):
    def __init__(self, in_dim: int = 8, edge_dim: int = 4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 128), nn.ReLU(),
            nn.Linear(128, 128), nn.ReLU(),
            nn.Linear(128, 64), nn.ReLU(),
        )
        self.out_dim = 128

    def forward(self, x, edge_index, edge_attr, batch):
        h = self.net(x)
        return torch.cat([global_mean_pool(h, batch),
                          global_max_pool(h, batch)], dim=-1)

    def attention_entropy(self) -> float:
        return 0.0


ENCODERS = {"gat": GATEncoder, "gcn": GCNEncoder, "mlp": MLPEncoder}


class ActorCritic(nn.Module):
    """Shared encoder with separate actor and critic MLP heads.

    The actor outputs the mean of a diagonal Gaussian policy with a
    learnable log standard deviation; the critic outputs a scalar value.
    """

    def __init__(self, encoder: str = "gat", n_actions: int = 3,
                 in_dim: int = 8, edge_dim: int = 4):
        super().__init__()
        self.encoder = ENCODERS[encoder](in_dim, edge_dim)
        d = self.encoder.out_dim
        self.actor = nn.Sequential(
            nn.Linear(d, 64), nn.ReLU(),
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, n_actions),
        )
        self.critic = nn.Sequential(
            nn.Linear(d, 64), nn.ReLU(),
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, 1),
        )
        self.log_std = nn.Parameter(torch.full((n_actions,), -0.5))

    def forward(self, data):
        batch = getattr(data, "batch", None)
        if batch is None:
            batch = torch.zeros(data.x.size(0), dtype=torch.long,
                                device=data.x.device)
        z = self.encoder(data.x, data.edge_index, data.edge_attr, batch)
        mean = torch.tanh(self.actor(z))
        value = self.critic(z).squeeze(-1)
        return mean, value

    def act(self, data, deterministic: bool = False):
        mean, value = self.forward(data)
        std = self.log_std.exp()
        dist = torch.distributions.Normal(mean, std)
        action = mean if deterministic else dist.sample()
        log_prob = dist.log_prob(action).sum(-1)
        return (action.clamp(-1.0, 1.0).detach(),
                log_prob.detach(), value.detach())

    def evaluate(self, data, action):
        mean, value = self.forward(data)
        std = self.log_std.exp()
        dist = torch.distributions.Normal(mean, std)
        log_prob = dist.log_prob(action).sum(-1)
        entropy = dist.entropy().sum(-1)
        return log_prob, value, entropy

    def num_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters())
