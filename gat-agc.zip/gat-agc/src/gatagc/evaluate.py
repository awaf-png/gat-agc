"""Evaluation harness.

Runs a fixed number of evaluation episodes under common random seeds
and computes the frequency-regulation and sustainability metrics
reported in the paper (maximum frequency deviation, settling time,
overshoot, ITAE/ITSE/ISE of the ACE, overload count, fuel cost, CO2,
renewable utilisation, composite reward).
"""

from __future__ import annotations

import numpy as np

from .environment import HybridMicrogridEnv


def _settling_time(df_trace, dt, band=0.02):
    df = np.abs(np.asarray(df_trace))
    if df.max() < band:
        return 0.0
    for k in range(len(df) - 1, -1, -1):
        if df[k] > band:
            return (k + 1) * dt
    return 0.0


def evaluate_controller(controller, n_episodes=200, seed0=1000,
                        episode_steps=500, n_buses=6,
                        renewable_scale=1.0, line_outage=None,
                        is_graph=True):
    rewards, dfmax, settle, over = [], [], [], []
    itae, itse, ise, ovl = [], [], [], []
    fuel, co2, renu = [], [], []

    for ep in range(n_episodes):
        env = HybridMicrogridEnv(
            seed=seed0 + ep, episode_steps=episode_steps,
            n_buses=n_buses, renewable_scale=renewable_scale)
        if line_outage is not None:
            env.set_line_outage(line_outage)
        if hasattr(controller, "reset"):
            controller.reset()
        obs = env.reset()
        r_sum = 0.0
        df_tr, ace_tr, ov_cnt = [], [], 0
        info = None
        for t in range(episode_steps):
            if is_graph:
                a = controller.act(obs, info) if _wants_info(controller) \
                    else controller.act(obs)
            else:
                a = controller.act(obs, info)
            obs, r, done, info = env.step(a)
            r_sum += r
            df_tr.append(info["df"])
            ace_tr.append(info["ace"])
            if info["overload"] > 0:
                ov_cnt += 1
            if done:
                break

        df_tr = np.asarray(df_tr)
        ace_tr = np.asarray(ace_tr)
        tvec = np.arange(len(ace_tr)) * env.dt
        rewards.append(r_sum)
        dfmax.append(float(np.max(np.abs(df_tr)) / 50.0))
        settle.append(_settling_time(df_tr / 50.0, env.dt))
        over.append(float(np.max(np.abs(df_tr)) / 50.0 /
                          (np.std(df_tr / 50.0) + 1e-6)))
        itae.append(float(np.sum(tvec * np.abs(ace_tr)) * env.dt))
        itse.append(float(np.sum(tvec * ace_tr ** 2) * env.dt))
        ise.append(float(np.sum(ace_tr ** 2) * env.dt))
        ovl.append(ov_cnt / max(1, len(ace_tr)) * 100.0)
        s = env.episode_summary()
        fuel.append(s["fuel_cost"])
        co2.append(s["co2_kg"])
        renu.append(s["renewable_util_pct"])

    return {
        "reward_mean": float(np.mean(rewards)),
        "reward_std": float(np.std(rewards)),
        "df_max": float(np.mean(dfmax)),
        "settling_s": float(np.mean(settle)),
        "overshoot": float(np.mean(over)),
        "ITAE": float(np.mean(itae)),
        "ITSE": float(np.mean(itse)),
        "ISE": float(np.mean(ise)),
        "overload_cnt": float(np.mean(ovl)),
        "fuel_cost": float(np.mean(fuel)),
        "co2_kg": float(np.mean(co2)),
        "renewable_util_pct": float(np.mean(renu)),
        "rewards_per_episode": rewards,
    }


def _wants_info(controller) -> bool:
    import inspect
    try:
        sig = inspect.signature(controller.act)
        return len(sig.parameters) >= 2
    except (TypeError, ValueError):
        return False
