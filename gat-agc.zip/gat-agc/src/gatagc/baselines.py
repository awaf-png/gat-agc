"""Model-based baseline controllers.

* :class:`PIDController` and :class:`PIController` implement the
  secondary AGC law of Eq. (5). Gains are obtained by Ziegler-Nichols
  tuning on the open-loop step response and refined on the training
  window.
* :class:`MPCController` solves a short finite-horizon quadratic
  program over the diesel reference at every step.

All three expose the same ``act(obs, info)`` interface as the learned
controllers so the evaluation harness can treat them uniformly. The
graph observation is reduced to the area control error, which is the
only signal these controllers use.
"""

from __future__ import annotations

import numpy as np


def _ace_from_obs(obs, info=None) -> float:
    if info is not None and "ace" in info:
        return float(info["ace"])
    df = obs.x[:, 4].mean().item()
    return float(0.425 * df)


class PIDController:
    def __init__(self, kp=1.5, ki=0.8, kd=0.05, dt=0.1):
        self.kp, self.ki, self.kd, self.dt = kp, ki, kd, dt
        self.reset()

    def reset(self):
        self._int = 0.0
        self._prev = 0.0

    def act(self, obs, info=None):
        e = _ace_from_obs(obs, info)
        self._int += e * self.dt
        de = (e - self._prev) / self.dt
        self._prev = e
        u = -(self.kp * e + self.ki * self._int + self.kd * de)
        u = float(np.clip(u, -1.0, 1.0))
        return np.array([u, 0.0, 0.0], dtype=np.float32)


class PIController:
    def __init__(self, kp=1.2, ki=0.6, dt=0.1):
        self.kp, self.ki, self.dt = kp, ki, dt
        self.reset()

    def reset(self):
        self._int = 0.0

    def act(self, obs, info=None):
        e = _ace_from_obs(obs, info)
        self._int += e * self.dt
        u = -(self.kp * e + self.ki * self._int)
        u = float(np.clip(u, -1.0, 1.0))
        return np.array([u, 0.0, 0.0], dtype=np.float32)


class MPCController:
    """Short-horizon quadratic MPC on the diesel reference.

    A scalar internal model df_{k+1} = a df_k + b u_k is used to predict
    the area control error over ``horizon`` steps; the first move of the
    minimising control sequence is applied (receding horizon).
    """

    def __init__(self, horizon=10, a=0.92, b=-0.18, dt=0.1):
        self.h = horizon
        self.a = a
        self.b = b
        self.dt = dt

    def reset(self):
        pass

    def act(self, obs, info=None):
        e0 = _ace_from_obs(obs, info)
        # closed-form first move for a 1-D LQ tracking problem
        num, den, x = 0.0, 0.0, e0
        for k in range(self.h):
            num += (self.a ** k) * self.b * x
            den += (self.b ** 2) * (k + 1)
            x *= self.a
        u = 0.0 if den < 1e-9 else float(np.clip(-num / den, -1.0, 1.0))
        return np.array([u, 0.0, 0.0], dtype=np.float32)


BASELINES = {
    "pid": PIDController,
    "pi": PIController,
    "mpc": MPCController,
}
