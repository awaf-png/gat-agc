"""Proximal Policy Optimization trainer for the graph controllers.

Implements the clipped surrogate objective with a value-function loss
and an entropy bonus, and Generalized Advantage Estimation for the
advantage targets. Graph observations are mini-batched with the
PyTorch Geometric ``Batch`` object so that variable-size graphs are
concatenated into a single block-diagonal graph.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
from torch_geometric.data import Batch

from .networks import ActorCritic


class PPOTrainer:
    def __init__(self, encoder: str = "gat", lr: float = 3e-4,
                 gamma: float = 0.99, gae_lambda: float = 0.95,
                 clip_eps: float = 0.2, c1: float = 0.5, c2: float = 0.01,
                 epochs: int = 4, minibatch: int = 32,
                 rollout: int = 2048, device: str = "cpu"):
        self.device = torch.device(device)
        self.net = ActorCritic(encoder=encoder).to(self.device)
        self.opt = torch.optim.Adam(self.net.parameters(), lr=lr)
        self.gamma = gamma
        self.lam = gae_lambda
        self.clip = clip_eps
        self.c1 = c1
        self.c2 = c2
        self.epochs = epochs
        self.minibatch = minibatch
        self.rollout = rollout

    # ------------------------------------------------------------------
    def _gae(self, rewards, values, dones, last_value):
        adv = np.zeros(len(rewards), dtype=np.float32)
        gae = 0.0
        for t in reversed(range(len(rewards))):
            next_v = last_value if t == len(rewards) - 1 else values[t + 1]
            mask = 1.0 - float(dones[t])
            delta = rewards[t] + self.gamma * next_v * mask - values[t]
            gae = delta + self.gamma * self.lam * mask * gae
            adv[t] = gae
        returns = adv + np.asarray(values, dtype=np.float32)
        return adv, returns

    # ------------------------------------------------------------------
    def collect(self, env, n_steps):
        obs_list, act_list, logp_list = [], [], []
        rew_list, val_list, done_list = [], [], []
        obs = env.reset()
        for _ in range(n_steps):
            data = obs.to(self.device)
            with torch.no_grad():
                action, logp, value = self.net.act(data)
            a = action.cpu().numpy().reshape(-1)
            nxt, reward, done, _ = env.step(a)
            obs_list.append(obs)
            act_list.append(action.cpu())
            logp_list.append(float(logp))
            rew_list.append(float(reward))
            val_list.append(float(value))
            done_list.append(bool(done))
            obs = env.reset() if done else nxt
        with torch.no_grad():
            _, _, last_v = self.net.act(obs.to(self.device))
        adv, ret = self._gae(rew_list, val_list, done_list, float(last_v))
        return (obs_list, act_list, np.asarray(logp_list, dtype=np.float32),
                adv, ret)

    # ------------------------------------------------------------------
    def update(self, batch):
        obs_list, act_list, old_logp, adv, ret = batch
        n = len(obs_list)
        adv = (adv - adv.mean()) / (adv.std() + 1e-8)
        adv_t = torch.tensor(adv, device=self.device)
        ret_t = torch.tensor(ret, device=self.device)
        old_logp_t = torch.tensor(old_logp, device=self.device)
        acts = torch.stack(act_list).to(self.device)

        idx = np.arange(n)
        for _ in range(self.epochs):
            np.random.shuffle(idx)
            for s in range(0, n, self.minibatch):
                mb = idx[s:s + self.minibatch]
                graphs = Batch.from_data_list(
                    [obs_list[i] for i in mb]).to(self.device)
                logp, value, ent = self.net.evaluate(graphs, acts[mb])
                ratio = (logp - old_logp_t[mb]).exp()
                s1 = ratio * adv_t[mb]
                s2 = torch.clamp(ratio, 1 - self.clip,
                                 1 + self.clip) * adv_t[mb]
                policy_loss = -torch.min(s1, s2).mean()
                value_loss = nn.functional.mse_loss(value, ret_t[mb])
                loss = (policy_loss + self.c1 * value_loss
                        - self.c2 * ent.mean())
                self.opt.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(self.net.parameters(), 0.5)
                self.opt.step()

    # ------------------------------------------------------------------
    def train(self, env, episodes, steps_per_episode, log_every=50,
              logger=None):
        history = []
        for ep in range(1, episodes + 1):
            batch = self.collect(env, steps_per_episode)
            self.update(batch)
            ep_reward = float(np.sum(batch[3] + batch[4]) / steps_per_episode)
            history.append(ep_reward)
            if logger is not None and ep % log_every == 0:
                logger(ep, ep_reward)
        return history

    def save(self, path):
        torch.save(self.net.state_dict(), path)

    def load(self, path):
        self.net.load_state_dict(
            torch.load(path, map_location=self.device))
