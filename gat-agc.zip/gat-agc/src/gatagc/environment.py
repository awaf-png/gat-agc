"""Hybrid AC/DC microgrid environment.

The microgrid is represented as an undirected attributed graph
G = (V, E, X, E_attr). Bus dynamics follow the second-order swing
equation; the secondary AGC loop acts on the area control error.
Renewable generation, EV charging and battery storage are driven by
the stochastic models documented in the paper. Sensor readings are
corrupted by delay, additive Gaussian noise and Bernoulli packet loss
before being handed to the controller.

The class exposes a Gym-style API (reset / step) and returns a
PyTorch Geometric ``Data`` object as the observation so that the
graph controllers can consume it directly.
"""

from __future__ import annotations

import numpy as np
import torch
from torch_geometric.data import Data

F0 = 50.0  # nominal system frequency [Hz]


class HybridMicrogridEnv:
    """6-bus hybrid AC/DC microgrid AGC environment.

    Node features (per bus, 8 dims):
        [P_inj, Q_inj, V, theta, df, SoC, P_ren_forecast, P_load]
    Edge features (per line, 4 dims):
        [R, X, P_flow, P_limit]
    Action (3 dims, all in [-1, 1]):
        [delta_P_ref_diesel, P_charge_BESS, demand_response_bus6]
    """

    N_NODE_FEATURES = 8
    N_EDGE_FEATURES = 4
    N_ACTIONS = 3

    def __init__(self, seed: int = 42, dt: float = 0.1,
                 episode_steps: int = 500, n_buses: int = 6,
                 renewable_scale: float = 1.0):
        self.rng = np.random.default_rng(seed)
        self.dt = dt
        self.episode_steps = episode_steps
        self.n_buses = n_buses
        self.renewable_scale = renewable_scale

        # Bus roles: 0 PCC, 1 PV, 2 wind, 3 diesel, 4 BESS+EV, 5 load.
        # For n_buses > 6 the extra buses are appended as radial load
        # taps on the 6-bus skeleton (see _build_topology).
        self.bus_types = ["PCC", "PV", "Wind", "Diesel", "BESS_EV", "Load"]
        self.P_rated = np.array([50.0, 20.0, 15.0, 10.0, 8.0, 25.0])
        self.M = np.array([10.0, 3.0, 3.5, 5.0, 2.0, 4.0])   # inertia const.
        self.D = np.array([1.5, 0.8, 0.9, 1.2, 0.7, 1.0])    # damping
        self.B_area = 0.425                                  # frequency bias

        # Battery
        self.E_max = 20.0          # MWh
        self.eta_c = 0.95
        self.eta_d = 0.95
        self.SoC_min = 0.1
        self.SoC_max = 0.9
        self.P_bess_max = 4.0      # MW

        # Diesel quadratic fuel cost a P^2 + b P + c
        self.a_cost = 0.002
        self.b_cost = 2.5
        self.c_cost = 50.0
        self.emission_factor = 0.7  # kg CO2 per kWh of diesel energy

        # Reward weights (alpha, beta, gamma, delta)
        self.alpha = 0.35
        self.beta = 0.25
        self.gamma = 0.25
        self.delta_w = 0.15

        # IoT measurement imperfections
        self.sigma_noise = 0.01
        self.packet_loss_p = 0.03
        self.sensor_delay_steps = 1

        self._build_topology(n_buses)
        self.t = 0
        self.reset()

    # ------------------------------------------------------------------
    # topology
    # ------------------------------------------------------------------
    def _build_topology(self, n_buses: int) -> None:
        # 6-bus skeleton: seven undirected lines.
        base_edges = [(0, 1), (0, 3), (1, 2), (2, 4),
                      (3, 5), (4, 5), (1, 5)]
        base_Z = np.array([
            [0.020, 0.080], [0.030, 0.100], [0.025, 0.090],
            [0.015, 0.050], [0.020, 0.070], [0.018, 0.060],
            [0.022, 0.085],
        ])
        base_limit = np.array([25.0, 20.0, 18.0, 15.0, 12.0, 10.0, 15.0])

        edges = list(base_edges)
        Z = list(base_Z)
        limit = list(base_limit)

        # Extend radially for larger systems: each extra bus is a load
        # tap hung off the existing load bus chain.
        prev = 5
        for b in range(6, n_buses):
            r = float(self.rng.uniform(0.015, 0.10))
            x = float(self.rng.uniform(0.05, 0.10))
            edges.append((prev, b))
            Z.append([r, x])
            limit.append(float(self.rng.uniform(10.0, 25.0)))
            prev = b

        self.edges = edges
        self.Z = np.asarray(Z)
        self.P_limit_line = np.asarray(limit)

        if n_buses > 6:
            extra = n_buses - 6
            self.P_rated = np.concatenate(
                [self.P_rated, self.rng.uniform(5.0, 15.0, extra)])
            self.M = np.concatenate(
                [self.M, self.rng.uniform(3.0, 10.0, extra)])
            self.D = np.concatenate(
                [self.D, self.rng.uniform(0.7, 1.5, extra)])

        # Directed edge index for message passing (both directions).
        ei = []
        for (i, j) in self.edges:
            ei.append([i, j])
            ei.append([j, i])
        self.edge_index = torch.tensor(ei, dtype=torch.long).t().contiguous()
        self._active_mask = np.ones(len(self.edges), dtype=bool)

    def set_line_outage(self, line_idx: int | None) -> None:
        """Trip a single line (None re-closes all lines)."""
        self._active_mask[:] = True
        if line_idx is not None and 0 <= line_idx < len(self.edges):
            self._active_mask[line_idx] = False
        ei = []
        for k, (i, j) in enumerate(self.edges):
            if not self._active_mask[k]:
                continue
            ei.append([i, j])
            ei.append([j, i])
        self.edge_index = torch.tensor(ei, dtype=torch.long).t().contiguous()

    # ------------------------------------------------------------------
    # stochastic resource models
    # ------------------------------------------------------------------
    def _solar_power(self, t_sec: float) -> float:
        hour = (t_sec % 50.0) / 50.0 * 24.0
        base = self.P_rated[1] * max(0.0, np.sin(np.pi * hour / 24.0))
        noise = self.rng.normal(0.0, 0.08)
        return self.renewable_scale * max(0.0, base * (1.0 + noise))

    def _wind_power(self, t_sec: float) -> float:
        v = self.rng.rayleigh(7.0)
        v_ci, v_rated, v_co = 3.0, 12.0, 25.0
        if v < v_ci or v > v_co:
            p = 0.0
        elif v < v_rated:
            p = self.P_rated[2] * (v ** 3 - v_ci ** 3) / \
                (v_rated ** 3 - v_ci ** 3)
        else:
            p = self.P_rated[2]
        return self.renewable_scale * float(np.clip(p, 0.0, self.P_rated[2]))

    def _ev_load(self) -> float:
        n_arr = self.rng.poisson(5.0 / 36000.0 * (self.dt / 0.1))
        return float(n_arr * max(0.0, self.rng.normal(7.0e-3, 1.0e-3)))

    def _base_load(self, t_sec: float) -> float:
        hour = (t_sec % 50.0) / 50.0 * 24.0
        shape = 0.7 + 0.3 * np.sin(np.pi * (hour - 6.0) / 12.0) ** 2
        return self.P_rated[5] * shape

    # ------------------------------------------------------------------
    # core API
    # ------------------------------------------------------------------
    def reset(self) -> Data:
        self.t = 0
        n = self.n_buses
        self.df = np.zeros(n)               # frequency deviation per bus
        self.dw = np.zeros(n)               # per-unit speed deviation
        self.theta = np.zeros(n)
        self.V = np.ones(n)
        self.SoC = 0.5
        self.P_diesel = 4.0
        self.ace_int = 0.0
        self.P_tie = 0.0
        self._delay_buffer = []
        self._prev_obs = None
        self.episode_cost = 0.0
        self.episode_emission = 0.0
        self.episode_renewable = 0.0
        self.episode_demand = 0.0
        return self._build_obs()

    def _raw_node_features(self) -> np.ndarray:
        t_sec = self.t * self.dt
        n = self.n_buses
        x = np.zeros((n, self.N_NODE_FEATURES), dtype=np.float32)

        p_solar = self._solar_power(t_sec)
        p_wind = self._wind_power(t_sec)
        p_load = self._base_load(t_sec) + self._ev_load() * 100.0

        # P_inj per bus (sign convention: generation positive)
        p_inj = np.zeros(n)
        p_inj[0] = self.P_tie
        p_inj[1] = p_solar
        p_inj[2] = p_wind
        p_inj[3] = self.P_diesel
        p_inj[5] = -p_load
        for b in range(6, n):
            p_inj[b] = -0.5 * self._base_load(t_sec) / max(1, n - 6)

        ren_forecast = np.zeros(n)
        ren_forecast[1] = p_solar
        ren_forecast[2] = p_wind

        load_vec = np.zeros(n)
        load_vec[5] = p_load

        soc_vec = np.zeros(n)
        soc_vec[4] = self.SoC

        x[:, 0] = p_inj / 50.0
        x[:, 1] = 0.0
        x[:, 2] = self.V
        x[:, 3] = self.theta
        x[:, 4] = self.df
        x[:, 5] = soc_vec
        x[:, 6] = ren_forecast / 20.0
        x[:, 7] = load_vec / 25.0

        self._last_resources = (p_solar, p_wind, p_load)
        return x

    def _apply_iot_imperfections(self, x: np.ndarray) -> np.ndarray:
        # sensing delay
        self._delay_buffer.append(x.copy())
        if len(self._delay_buffer) > self.sensor_delay_steps:
            delayed = self._delay_buffer.pop(0)
        else:
            delayed = x.copy()
        # additive Gaussian noise
        noisy = delayed + self.rng.normal(
            0.0, self.sigma_noise, size=delayed.shape).astype(np.float32)
        # Bernoulli packet loss -> hold last received value
        if self._prev_obs is not None:
            drop = self.rng.random(noisy.shape[0]) < self.packet_loss_p
            noisy[drop] = self._prev_obs[drop]
        self._prev_obs = noisy.copy()
        return noisy

    def _edge_features(self) -> torch.Tensor:
        feats = []
        t_sec = self.t * self.dt
        for k, (i, j) in enumerate(self.edges):
            if not self._active_mask[k]:
                continue
            r, xr = self.Z[k]
            dtheta = self.theta[i] - self.theta[j]
            p_flow = self.V[i] * self.V[j] / max(xr, 1e-3) * np.sin(dtheta)
            limit = self.P_limit_line[k]
            f = [r, xr, p_flow / 25.0, limit / 25.0]
            feats.append(f)
            feats.append(f)  # both directions
        return torch.tensor(feats, dtype=torch.float32)

    def _build_obs(self) -> Data:
        x_raw = self._raw_node_features()
        x_obs = self._apply_iot_imperfections(x_raw)
        data = Data(
            x=torch.tensor(x_obs, dtype=torch.float32),
            edge_index=self.edge_index,
            edge_attr=self._edge_features(),
        )
        return data

    def step(self, action: np.ndarray):
        action = np.clip(np.asarray(action, dtype=np.float32), -1.0, 1.0)
        t_sec = self.t * self.dt
        p_solar, p_wind, p_load = self._last_resources

        # --- map normalised action to physical set-points ----------------
        dP_ref = action[0] * 2.0                       # MW reference step
        self.P_diesel = float(np.clip(
            self.P_diesel + dP_ref, 0.0, self.P_rated[3]))

        p_bess_cmd = action[1] * self.P_bess_max       # +charge / -discharge
        # SoC limits act as hard constraints
        if p_bess_cmd > 0 and self.SoC >= self.SoC_max:
            p_bess_cmd = 0.0
        if p_bess_cmd < 0 and self.SoC <= self.SoC_min:
            p_bess_cmd = 0.0
        dE = (self.eta_c * max(p_bess_cmd, 0.0)
              - (1.0 / self.eta_d) * max(-p_bess_cmd, 0.0)) * self.dt / 3600.0
        self.SoC = float(np.clip(
            self.SoC + dE / self.E_max, self.SoC_min, self.SoC_max))

        dr = max(0.0, action[2]) * 0.15 * p_load        # curtailable share
        p_load_eff = p_load - dr

        # --- power balance and swing dynamics ---------------------------
        p_gen = (self.P_diesel + p_solar + p_wind
                 - max(p_bess_cmd, 0.0) + max(-p_bess_cmd, 0.0))
        imbalance = (p_gen - p_load_eff) / 50.0          # per-unit

        # single lumped-area swing update (Eq. 4) with neighbour coupling
        for b in range(self.n_buses):
            dwn = (imbalance - self.D[b] * self.dw[b]) / self.M[b]
            self.dw[b] += dwn * self.dt
            self.df[b] = self.dw[b] * F0
            self.theta[b] += 2.0 * np.pi * self.df[b] * self.dt
        self.theta -= self.theta.mean()

        # PCC interchange tracks slow imbalance in grid-tied mode
        self.P_tie = float(np.clip(self.P_tie + 0.5 * imbalance, -50.0, 50.0))

        # --- area control error and reward (Eq. 6, Eq. 11) --------------
        df_mean = float(self.df.mean())
        ace = self.B_area * df_mean + self.P_tie / 50.0
        self.ace_int += ace * self.dt

        fuel = (self.a_cost * self.P_diesel ** 2
                + self.b_cost * self.P_diesel + self.c_cost)
        emission = self.emission_factor * self.P_diesel * self.dt / 3600.0
        p_tot = p_solar + p_wind + self.P_diesel + 1e-6
        ren_frac = (p_solar + p_wind) / p_tot

        overload = 0.0
        ef = self._edge_features()
        if ef.numel() > 0:
            flow = ef[:, 2].abs().numpy() * 25.0
            lim = ef[:, 3].numpy() * 25.0
            overload = float(np.sum(np.clip(flow - lim, 0.0, None) ** 2))

        reward = -(self.alpha * ace ** 2
                   + self.beta * fuel / 100.0
                   + self.gamma * (1.0 - ren_frac)
                   + self.delta_w * overload / 100.0)

        self.episode_cost += fuel * self.dt / 50.0
        self.episode_emission += emission
        self.episode_renewable += (p_solar + p_wind) * self.dt
        self.episode_demand += p_tot * self.dt

        self.t += 1
        done = self.t >= self.episode_steps
        info = {
            "ace": ace,
            "df": df_mean,
            "fuel": fuel,
            "emission": emission,
            "ren_frac": ren_frac,
            "overload": overload,
            "P_diesel": self.P_diesel,
            "SoC": self.SoC,
        }
        return self._build_obs(), float(reward), done, info

    # ------------------------------------------------------------------
    def episode_summary(self) -> dict:
        ren_util = (self.episode_renewable
                    / max(self.episode_demand, 1e-6)) * 100.0
        return {
            "fuel_cost": self.episode_cost,
            "co2_kg": self.episode_emission,
            "renewable_util_pct": float(np.clip(ren_util, 0.0, 100.0)),
        }
