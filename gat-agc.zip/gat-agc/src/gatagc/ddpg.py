"""Flat-vector DDPG baseline (DDPG-AGC).

The graph observation is flattened to a fixed-length vector (padded to
the largest evaluated bus count) so that a standard MLP actor-critic
can consume it. This is the topology-agnostic deep-RL baseline used
for comparison against the graph controllers.
"""

from __future__ import annotations

import copy

import numpy as np
import torch
import torch.nn as nn


def flatten_obs(obs, max_nodes: int = 20, n_feat: int = 8) -> np.ndarray:
    x = obs.x.detach().cpu().numpy()
    flat = np.zeros(max_nodes * n_feat, dtype=np.float32)
    n = min(x.shape[0], max_nodes)
    flat[: n * n_feat] = x[:n].reshape(-1)
    return flat


class _MLP(nn.Module):
    def __init__(self, sizes, out_act=None):
        super().__init__()
        layers = []
        for i in range(len(sizes) - 1):
            layers.append(nn.Linear(sizes[i], sizes[i + 1]))
            if i < len(sizes) - 2:
                layers.append(nn.ReLU())
        if out_act is not None:
            layers.append(out_act)
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


class DDPGAgent:
    def __init__(self, obs_dim=160, act_dim=3, gamma=0.99, tau=0.005,
                 lr=1e-3, device="cpu"):
        self.device = torch.device(device)
        self.actor = _MLP([obs_dim, 256, 256, act_dim],
                          out_act=nn.Tanh()).to(self.device)
        self.critic = _MLP([obs_dim + act_dim, 256, 256, 1]).to(self.device)
        self.actor_t = copy.deepcopy(self.actor)
        self.critic_t = copy.deepcopy(self.critic)
        self.a_opt = torch.optim.Adam(self.actor.parameters(), lr=lr)
        self.c_opt = torch.optim.Adam(self.critic.parameters(), lr=lr)
        self.gamma = gamma
        self.tau = tau
        self.buf = []
        self.buf_cap = 100_000

    def act(self, obs, info=None, noise=0.0):
        s = torch.tensor(flatten_obs(obs), device=self.device).unsqueeze(0)
        with torch.no_grad():
            a = self.actor(s).cpu().numpy().reshape(-1)
        if noise > 0:
            a = a + np.random.normal(0.0, noise, size=a.shape)
        return np.clip(a, -1.0, 1.0).astype(np.float32)

    def store(self, s, a, r, s2, d):
        if len(self.buf) >= self.buf_cap:
            self.buf.pop(0)
        self.buf.append((s, a, r, s2, d))

    def update(self, batch_size=64):
        if len(self.buf) < batch_size:
            return
        idx = np.random.randint(0, len(self.buf), batch_size)
        s, a, r, s2, d = zip(*[self.buf[i] for i in idx])
        s = torch.tensor(np.array(s), device=self.device)
        a = torch.tensor(np.array(a), device=self.device)
        r = torch.tensor(np.array(r), device=self.device).unsqueeze(-1)
        s2 = torch.tensor(np.array(s2), device=self.device)
        d = torch.tensor(np.array(d, dtype=np.float32),
                         device=self.device).unsqueeze(-1)
        with torch.no_grad():
            tq = self.critic_t(torch.cat(
                [s2, self.actor_t(s2)], dim=-1))
            y = r + self.gamma * (1 - d) * tq
        q = self.critic(torch.cat([s, a], dim=-1))
        c_loss = nn.functional.mse_loss(q, y)
        self.c_opt.zero_grad()
        c_loss.backward()
        self.c_opt.step()

        a_loss = -self.critic(torch.cat(
            [s, self.actor(s)], dim=-1)).mean()
        self.a_opt.zero_grad()
        a_loss.backward()
        self.a_opt.step()

        for p, pt in zip(self.actor.parameters(),
                         self.actor_t.parameters()):
            pt.data.mul_(1 - self.tau).add_(self.tau * p.data)
        for p, pt in zip(self.critic.parameters(),
                         self.critic_t.parameters()):
            pt.data.mul_(1 - self.tau).add_(self.tau * p.data)

    def train(self, env, episodes, steps, logger=None, log_every=50):
        history = []
        for ep in range(1, episodes + 1):
            obs = env.reset()
            ep_r = 0.0
            for _ in range(steps):
                s = flatten_obs(obs)
                a = self.act(obs, noise=0.1)
                nxt, r, done, _ = env.step(a)
                self.store(s, a, r, flatten_obs(nxt), done)
                self.update()
                ep_r += r
                obs = env.reset() if done else nxt
            history.append(ep_r / steps)
            if logger is not None and ep % log_every == 0:
                logger(ep, ep_r / steps)
        return history

    def save(self, path):
        torch.save(self.actor.state_dict(), path)

    def load(self, path):
        self.actor.load_state_dict(
            torch.load(path, map_location=self.device))
