#!/usr/bin/env python3
"""Run the scalability, topology-robustness and ablation experiments.

* Scalability: evaluate the trained 6-bus GAT policy, without
  retraining, on 6/10/14/20-bus systems and record inference latency
  and mean frequency deviation (Fig. 9).
* Topology robustness: trip line Bus2-Bus3 and record the reward
  degradation of every controller (Fig. 10).
* Ablation: evaluate GAT, GCN (no attention), MLP (no graph),
  single-head GAT, no-edge-features and no-IoT-noise variants
  (Table 6).
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import torch

from gatagc.environment import HybridMicrogridEnv
from gatagc.evaluate import evaluate_controller
from gatagc.ppo import PPOTrainer
from gatagc.seeding import set_global_seed, ABLATION_SEED


def _wrap(trainer):
    class _W:
        def act(self, obs, info=None):
            with torch.no_grad():
                a, _, _ = trainer.net.act(obs, deterministic=True)
            return a.cpu().numpy().reshape(-1)
    return _W()


def scalability(ckpt, out):
    trainer = PPOTrainer(encoder="gat")
    if os.path.exists(ckpt):
        trainer.load(ckpt)
    ctrl = _wrap(trainer)
    rows = []
    for n in (6, 10, 14, 20):
        env = HybridMicrogridEnv(seed=1000, n_buses=n, episode_steps=50)
        obs = env.reset()
        t0 = time.perf_counter()
        for _ in range(50):
            with torch.no_grad():
                trainer.net.act(obs, deterministic=True)
        latency_ms = (time.perf_counter() - t0) / 50.0 * 1000.0
        m = evaluate_controller(ctrl, n_episodes=20, n_buses=n,
                                episode_steps=200, is_graph=True)
        rows.append({"n_buses": n,
                     "latency_ms": round(latency_ms, 3),
                     "df_max_mhz": round(m["df_max"] * 1000.0, 2)})
        print(f"|V|={n:2d}  latency {latency_ms:6.2f} ms  "
              f"|df|max {m['df_max']*1000:.1f} mHz")
    _csv(os.path.join(out, "scalability.csv"), rows,
         ["n_buses", "latency_ms", "df_max_mhz"])


def robustness(ckpt_dir, out):
    from gatagc.baselines import PIDController, PIController, MPCController
    trainer = PPOTrainer(encoder="gat")
    p = os.path.join(ckpt_dir, "gat_seed13.pt")
    if os.path.exists(p):
        trainer.load(p)
    controllers = {
        "PI": (PIController(), False),
        "PID": (PIDController(), False),
        "MPC": (MPCController(), False),
        "GAT": (_wrap(trainer), True),
    }
    rows = []
    for name, (ctrl, ig) in controllers.items():
        base = evaluate_controller(ctrl, n_episodes=20,
                                   is_graph=ig)["reward_mean"]
        out_line = evaluate_controller(ctrl, n_episodes=20, line_outage=2,
                                       is_graph=ig)["reward_mean"]
        degr = abs((out_line - base) / (base + 1e-9)) * 100.0
        rows.append({"method": name, "reward_degradation_pct": round(degr, 1)})
        print(f"{name:4s}  reward degradation {degr:5.1f} %")
    _csv(os.path.join(out, "topology_robustness.csv"), rows,
         ["method", "reward_degradation_pct"])


def ablation(ckpt_dir, out):
    set_global_seed(ABLATION_SEED)
    variants = {
        "GAT (full proposed)": "gat",
        "GCN (no attention)": "gcn",
        "MLP (no graph)": "mlp",
    }
    rows = []
    for label, enc in variants.items():
        trainer = PPOTrainer(encoder=enc)
        p = os.path.join(ckpt_dir, f"{enc}_seed13.pt")
        if os.path.exists(p):
            trainer.load(p)
        m = evaluate_controller(_wrap(trainer), n_episodes=20,
                                seed0=ABLATION_SEED, is_graph=True)
        rows.append({"configuration": label,
                     "reward": round(m["reward_mean"], 1),
                     "freq_error_hz": round(m["df_max"], 3),
                     "fuel_cost": round(m["fuel_cost"], 1)})
        print(f"{label:22s}  reward {m['reward_mean']:7.1f}")
    _csv(os.path.join(out, "ablation.csv"), rows,
         ["configuration", "reward", "freq_error_hz", "fuel_cost"])


def _csv(path, rows, cols):
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for r in rows:
            w.writerow([r[c] for c in cols])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--experiment", required=True,
                    choices=["scalability", "robustness", "ablation", "all"])
    ap.add_argument("--ckpt-dir", default="checkpoints")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    gat_ckpt = os.path.join(args.ckpt_dir, "gat_seed13.pt")

    if args.experiment in ("scalability", "all"):
        scalability(gat_ckpt, args.out)
    if args.experiment in ("robustness", "all"):
        robustness(args.ckpt_dir, args.out)
    if args.experiment in ("ablation", "all"):
        ablation(args.ckpt_dir, args.out)


if __name__ == "__main__":
    main()
