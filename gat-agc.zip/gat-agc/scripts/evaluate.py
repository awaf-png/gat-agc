#!/usr/bin/env python3
"""Evaluate all controllers and write the result tables as CSV.

Reproduces Table 4 (frequency regulation), Table 5 (sustainability)
and the composite reward column. Trained checkpoints are loaded for
the learned controllers; classical controllers are instantiated
directly. Results are written to ``results/``.
"""

from __future__ import annotations

import argparse
import csv
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from gatagc.baselines import PIDController, PIController, MPCController
from gatagc.ddpg import DDPGAgent
from gatagc.evaluate import evaluate_controller
from gatagc.ppo import PPOTrainer
from gatagc.seeding import set_global_seed


def _graph_controller(encoder, ckpt):
    trainer = PPOTrainer(encoder=encoder)
    if ckpt and os.path.exists(ckpt):
        trainer.load(ckpt)

    class _Wrap:
        def act(self, obs, info=None):
            import torch
            with torch.no_grad():
                a, _, _ = trainer.net.act(obs, deterministic=True)
            return a.cpu().numpy().reshape(-1)

    return _Wrap()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--episodes", type=int, default=200)
    ap.add_argument("--seed", type=int, default=1000)
    ap.add_argument("--ckpt-dir", default="checkpoints")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()

    set_global_seed(args.seed)
    os.makedirs(args.out, exist_ok=True)

    controllers = {
        "PI": (PIController(), False),
        "PID": (PIDController(), False),
        "MPC": (MPCController(), False),
        "DDPG": (_load_ddpg(args.ckpt_dir), False),
        "GCN": (_graph_controller(
            "gcn", os.path.join(args.ckpt_dir, "gcn_seed13.pt")), True),
        "GAT": (_graph_controller(
            "gat", os.path.join(args.ckpt_dir, "gat_seed13.pt")), True),
    }

    rows = []
    for name, (ctrl, is_graph) in controllers.items():
        m = evaluate_controller(ctrl, n_episodes=args.episodes,
                                seed0=args.seed, is_graph=is_graph)
        m["method"] = name
        rows.append(m)
        print(f"{name:5s}  reward {m['reward_mean']:8.2f} "
              f"+/- {m['reward_std']:5.2f}  |df|max {m['df_max']:.4f}  "
              f"fuel {m['fuel_cost']:6.2f}  CO2 {m['co2_kg']:5.2f}")

    _write_csv(os.path.join(args.out, "table4_frequency.csv"), rows, [
        "method", "df_max", "settling_s", "overshoot",
        "ITAE", "ITSE", "ISE", "overload_cnt"])
    _write_csv(os.path.join(args.out, "table5_sustainability.csv"), rows, [
        "method", "fuel_cost", "co2_kg", "renewable_util_pct",
        "overload_cnt", "reward_mean"])
    print(f"\nResults written to {args.out}/")


def _load_ddpg(ckpt_dir):
    agent = DDPGAgent()
    p = os.path.join(ckpt_dir, "ddpg_seed13.pt")
    if os.path.exists(p):
        agent.load(p)

    class _Wrap:
        def act(self, obs, info=None):
            return agent.act(obs, noise=0.0)

    return _Wrap()


def _write_csv(path, rows, cols):
    with open(path, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(cols)
        for r in rows:
            w.writerow([r.get(c, "") for c in cols])


if __name__ == "__main__":
    main()
