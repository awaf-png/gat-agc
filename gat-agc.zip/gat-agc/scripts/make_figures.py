#!/usr/bin/env python3
"""Generate the result figures from the CSV outputs in results/.

Produces the training-convergence, frequency-response, sustainability,
scalability and ablation figures used in the paper. Run after
scripts/evaluate.py and scripts/experiments.py.
"""

from __future__ import annotations

import argparse
import csv
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


def _read_csv(path):
    with open(path) as fh:
        return list(csv.DictReader(fh))


def fig_sustainability(results_dir, out_dir):
    path = os.path.join(results_dir, "table5_sustainability.csv")
    if not os.path.exists(path):
        return
    rows = _read_csv(path)
    methods = [r["method"] for r in rows]
    fuel = [float(r["fuel_cost"]) for r in rows]
    co2 = [float(r["co2_kg"]) for r in rows]

    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    ax[0].bar(methods, fuel, color="#3b6ea5")
    ax[0].set_ylabel("Fuel cost ($)")
    ax[0].set_title("Fuel cost by controller")
    ax[1].bar(methods, co2, color="#6a8f3b")
    ax[1].set_ylabel("CO2 (kg)")
    ax[1].set_title("Emissions by controller")
    for a in ax:
        a.grid(True, axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "fig_sustainability.png"), dpi=300)
    plt.close(fig)


def fig_scalability(results_dir, out_dir):
    path = os.path.join(results_dir, "scalability.csv")
    if not os.path.exists(path):
        return
    rows = _read_csv(path)
    n = [int(r["n_buses"]) for r in rows]
    lat = [float(r["latency_ms"]) for r in rows]
    df = [float(r["df_max_mhz"]) for r in rows]

    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    ax[0].plot(n, lat, "o-", color="#3b6ea5")
    ax[0].set_xlabel("Number of buses")
    ax[0].set_ylabel("Inference latency (ms)")
    ax[0].set_title("Inference latency vs. system size")
    ax[1].plot(n, df, "s-", color="#a5503b")
    ax[1].set_xlabel("Number of buses")
    ax[1].set_ylabel("Mean |df|max (mHz)")
    ax[1].set_title("Regulation vs. system size")
    for a in ax:
        a.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "fig_scalability.png"), dpi=300)
    plt.close(fig)


def fig_ablation(results_dir, out_dir):
    path = os.path.join(results_dir, "ablation.csv")
    if not os.path.exists(path):
        return
    rows = _read_csv(path)
    labels = [r["configuration"] for r in rows]
    reward = [abs(float(r["reward"])) for r in rows]
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.barh(labels, reward, color="#3b6ea5")
    ax.set_xlabel("|Reward| (lower is better)")
    ax.set_title("Ablation study")
    ax.grid(True, axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, "fig_ablation.png"), dpi=300)
    plt.close(fig)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default="results")
    ap.add_argument("--out", default="figures")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)
    fig_sustainability(args.results, args.out)
    fig_scalability(args.results, args.out)
    fig_ablation(args.results, args.out)
    print(f"Figures written to {args.out}/")


if __name__ == "__main__":
    main()
