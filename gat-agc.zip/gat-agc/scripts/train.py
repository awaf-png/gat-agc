#!/usr/bin/env python3
"""Train one controller and save its checkpoint.

Usage
-----
    python scripts/train.py --controller gat   --episodes 1000 --seed 13
    python scripts/train.py --controller gcn   --episodes 1000 --seed 13
    python scripts/train.py --controller ddpg  --episodes 1000 --seed 13

The classical controllers (pid, pi, mpc) are model-based and require no
training; they are evaluated directly by scripts/evaluate.py.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from gatagc.environment import HybridMicrogridEnv
from gatagc.ppo import PPOTrainer
from gatagc.ddpg import DDPGAgent
from gatagc.seeding import set_global_seed


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--controller", required=True,
                    choices=["gat", "gcn", "mlp", "ddpg"])
    ap.add_argument("--episodes", type=int, default=1000)
    ap.add_argument("--steps", type=int, default=500)
    ap.add_argument("--seed", type=int, default=13)
    ap.add_argument("--n-buses", type=int, default=6)
    ap.add_argument("--out", default="checkpoints")
    args = ap.parse_args()

    set_global_seed(args.seed)
    os.makedirs(args.out, exist_ok=True)

    env = HybridMicrogridEnv(seed=args.seed, episode_steps=args.steps,
                             n_buses=args.n_buses)

    def logger(ep, r):
        print(f"[{args.controller}] episode {ep:4d}  "
              f"mean reward {r:8.3f}", flush=True)

    t0 = time.time()
    if args.controller == "ddpg":
        agent = DDPGAgent()
        history = agent.train(env, args.episodes, args.steps,
                              logger=logger)
        ckpt = os.path.join(args.out, f"{args.controller}_seed{args.seed}.pt")
        agent.save(ckpt)
    else:
        trainer = PPOTrainer(encoder=args.controller)
        if args.controller == "gat":
            print(f"parameters: {trainer.net.num_parameters()}")
        history = trainer.train(env, args.episodes, args.steps,
                                logger=logger)
        ckpt = os.path.join(args.out, f"{args.controller}_seed{args.seed}.pt")
        trainer.save(ckpt)

    elapsed = time.time() - t0
    meta = {
        "controller": args.controller,
        "episodes": args.episodes,
        "seed": args.seed,
        "n_buses": args.n_buses,
        "wall_time_s": round(elapsed, 1),
        "final_reward": round(float(history[-1]), 3),
        "checkpoint": ckpt,
    }
    with open(os.path.join(args.out,
              f"{args.controller}_seed{args.seed}.json"), "w") as fh:
        json.dump(meta, fh, indent=2)
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
